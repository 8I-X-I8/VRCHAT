﻿using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon.Common.Interfaces;

public class QRCodeScript : UdonSharpBehaviour
{
    [UdonSynced(UdonSyncMode.None), FieldChangeCallback(nameof(IsActive))]
    private bool isActive = false; // 用于同步的激活状态

    private Vector3 initialPosition; // 初始位置
    private Vector3 offsetPosition; // 初始位置向左1点的位置
    public QRCodeManager manager; // 引用 QRCodeManager
    public int qrCodeIndex; // 在 QRCodeManager 中的索引

    private void Start()
    {
        initialPosition = transform.localPosition;
        offsetPosition = initialPosition + Vector3.left * 1f; // 设置为向左1点

        // 初始化时根据同步状态设置二维码位置
        UpdateQRCodePosition();
    }

    public void TryActivate()
    {
        Networking.SetOwner(Networking.LocalPlayer, manager.gameObject);
        manager.SetActiveQRCode(qrCodeIndex);
    }

    public void Activate()
    {
        // 激活二维码
        IsActive = true;
        UpdateQRCodePosition();
    }

    public void Deactivate()
    {
        // 关闭二维码
        IsActive = false;
        UpdateQRCodePosition();
    }

    public void SetState(bool active)
    {
        isActive = active;
        UpdateQRCodePosition();
    }

    public bool IsActive
    {
        get => isActive;
        set
        {
            if (isActive == value) return;
            isActive = value;
            UpdateQRCodePosition();
        }
    }

    private void UpdateQRCodePosition()
    {
        // 根据激活状态更新二维码的位置
        transform.localPosition = isActive ? initialPosition : offsetPosition;
    }

    public override void OnDeserialization()
    {
        // 当接收到同步数据时，更新二维码位置
        UpdateQRCodePosition();
    }
}
