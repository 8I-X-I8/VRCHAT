﻿using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon;

public class QRCodeManager : UdonSharpBehaviour
{
    [UdonSynced(UdonSyncMode.None)]
    public int currentActiveQRCodeIndex = -1;

    public GameObject[] qrCodes;

    public void SetActiveQRCode(int newQRCodeIndex)
    {
        if (currentActiveQRCodeIndex == newQRCodeIndex)
        {
            return;
        }

        if (currentActiveQRCodeIndex >= 0 && currentActiveQRCodeIndex < qrCodes.Length)
        {
            QRCodeScript oldQRCodeScript = qrCodes[currentActiveQRCodeIndex].GetComponent<QRCodeScript>();
            if (oldQRCodeScript != null)
            {
                oldQRCodeScript.Deactivate();
            }
        }

        currentActiveQRCodeIndex = newQRCodeIndex;

        QRCodeScript newQRCodeScript = qrCodes[newQRCodeIndex].GetComponent<QRCodeScript>();
        if (newQRCodeScript != null)
        {
            newQRCodeScript.Activate();
        }

        RequestSerialization();
    }

    public override void OnDeserialization()
    {
        if (currentActiveQRCodeIndex >= 0 && currentActiveQRCodeIndex < qrCodes.Length)
        {
            for (int i = 0; i < qrCodes.Length; i++)
            {
                QRCodeScript qrCodeScript = qrCodes[i].GetComponent<QRCodeScript>();
                if (qrCodeScript != null)
                {
                    qrCodeScript.SetState(i == currentActiveQRCodeIndex);
                }
            }
        }
    }
}
