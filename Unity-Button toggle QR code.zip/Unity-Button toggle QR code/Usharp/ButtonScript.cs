﻿using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon;

public class ButtonScript : UdonSharpBehaviour
{
    public GameObject[] qrCodes; // 包含所有二维码的数组
    private int currentIndex = -1; // 当前激活二维码的索引

    public override void Interact()
    {
        // 切换到下一个二维码
        currentIndex = (currentIndex + 1) % qrCodes.Length;

        // 确保索引范围正确
        if (currentIndex >= 0 && currentIndex < qrCodes.Length)
        {
            // 调用新二维码对象上的 TryActivate 方法
            QRCodeScript newQRCodeScript = qrCodes[currentIndex].GetComponent<QRCodeScript>();
            if (newQRCodeScript != null)
            {
                newQRCodeScript.TryActivate();
            }
            else
            {
                Debug.LogError("QRCodeScript not found on the new object.");
            }
        }
        else
        {
            Debug.LogError("Current index is out of range.");
        }
    }
}
