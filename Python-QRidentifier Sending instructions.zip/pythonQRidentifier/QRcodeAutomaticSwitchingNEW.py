import multiprocessing
import time
import tkinter as tk
import qrcode
from PIL import Image, ImageTk
from pyzbar.pyzbar import decode
import serial
import pyautogui
from PIL import ImageDraw

# QR code commands
qr_commands = [
    "SET ALL DUTY CYCLES TO 15", "SET ALL DUTY CYCLES TO 35", "SET ALL DUTY CYCLES TO 100",
    "TURN_OFF_LIGHT", "BLINK_LIGHT", "TURN_OFF_BREATHING_EFFECT", "TURN_OFF_RED_LED",
    "SET RED DUTY CYCLE TO 15", "SET RED DUTY CYCLE TO 35", "SET RED DUTY CYCLE TO 100",
    "TURN_OFF_GREEN_LED", "SET GREEN DUTY CYCLE TO 15", "SET GREEN DUTY CYCLE TO 35",
    "SET GREEN DUTY CYCLE TO 100", "TURN_OFF_BLUE_LED", "SET BLUE DUTY CYCLE TO 15",
    "SET BLUE DUTY CYCLE TO 35", "SET BLUE DUTY CYCLE TO 100", "ENABLE_SOUND_CONTROL",
    "DISABLE_SOUND_CONTROL", "SPRAY FOR 5 SECONDS", "TOGGLE_SMOKE"
]

def generate():
    # 创建GUI窗口
    window = tk.Tk()
    window.title("QR Code Display")

    # 创建标签用于展示二维码图像
    qr_label = tk.Label(window)
    qr_label.pack()

    while True:
        for command in qr_commands:
            # 创建二维码对象
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_H,
                box_size=10,
                border=4,
            )

            # 添加数据到二维码
            qr.add_data(command)
            qr.make(fit=True)

            # 创建图像
            img = qr.make_image(fill_color="black", back_color="white")

            # 将PIL图像转换为Tkinter可用的图像格式
            img_tk = ImageTk.PhotoImage(img)

            # 更新标签展示新的二维码图像
            qr_label.config(image=img_tk)
            qr_label.image = img_tk  # 保持对图像对象的引用，防止被垃圾回收

            # 刷新窗口
            window.update()

            # 等待一段时间
            time.sleep(5)  # 等待

def scanner():
    screen_width, screen_height = pyautogui.size()
    left = (screen_width - 600) // 2
    top = (screen_height - 600) // 2
    width, height = 600, 600
    last_cmd = ""
    print("扫描器启动...")

    # 连接串口
    ser = serial.Serial('COM13', 115200, timeout=1)
    # 等待串口连接成功
    print("正在连接串口...")
    time.sleep(2.5)
    print("扫描器初始化完成...")

    # 创建一个窗口用于显示截图区域和矩形框
    root = tk.Tk()
    root.title("QR Code Scanner")
    canvas = tk.Canvas(root, width=width, height=height)
    canvas.pack()

    while True:
        # 捕捉屏幕中间的屏幕截图
        screenshot = pyautogui.screenshot(region=(left, top, width, height))

        # 将屏幕截图转换为PIL图像
        pil_image = Image.frombytes('RGB', screenshot.size, screenshot.tobytes())

        # 使用pyzbar进行二维码识别
        start_time = time.time()  # 记录开始时间
        results = decode(pil_image)

        # 打印识别到的二维码内容
        if results:
            current_cmd = results[0].data.decode("utf-8")
            if current_cmd != last_cmd:
                last_cmd = current_cmd
                cmd_to_send = get_cmd(current_cmd)
                if cmd_to_send is not None and cmd_to_send != "":
                    # 发送指令
                    message = cmd_to_send + '\n'
                    ser.write(message.encode())
                    end_time = time.time()  # 记录结束时间
                    delay = end_time - start_time  # 计算延迟
                    print(f"指令已发送: {cmd_to_send}")
                    print(f"从扫描到发送指令的延迟: {delay:.4f}秒")
                else:
                    print("指令发送失败: 识别到空指令")
        else:
            print("No QR Code found.")

        # 在图像上绘制绿色矩形框
        draw = ImageDraw.Draw(pil_image)
        draw.rectangle([(0, 0), (width - 1, height - 1)], outline="green", width=5)

        # 将PIL图像转换为Tkinter可用的图像格式
        img_tk = ImageTk.PhotoImage(pil_image)

        # 更新画布展示新的图像
        canvas.create_image(0, 0, anchor=tk.NW, image=img_tk)
        canvas.image = img_tk  # 保持对图像对象的引用，防止被垃圾回收

        # 刷新窗口
        root.update()

        time.sleep(0.1)

def get_cmd(cmd):
    if cmd in qr_commands:
        return cmd
    else:
        print(f"注意！识别到错误指令：{cmd}")
        return None

# run
if __name__ == "__main__":
    process1 = multiprocessing.Process(target=generate)
    process2 = multiprocessing.Process(target=scanner)
    process1.start()
    time.sleep(3)
    process2.start()

    process1.join()
    process2.join()
