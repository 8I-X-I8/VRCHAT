import qrcode
import os

# 要生成二维码的指令列表
commands = [
    "SET ALL DUTY CYCLES TO 15",
    "SET ALL DUTY CYCLES TO 35",
    "SET ALL DUTY CYCLES TO 100",
    "TURN_OFF_LIGHT",
    "BLINK_LIGHT",
    "TURN_OFF_BREATHING_EFFECT",
    "TURN_OFF_RED_LED",
    "SET RED DUTY CYCLE TO 15",
    "SET RED DUTY CYCLE TO 35",
    "SET RED DUTY CYCLE TO 100",
    "TURN_OFF_GREEN_LED",
    "SET GREEN DUTY CYCLE TO 15",
    "SET GREEN DUTY CYCLE TO 35",
    "SET GREEN DUTY CYCLE TO 100",
    "TURN_OFF_BLUE_LED",
    "SET BLUE DUTY CYCLE TO 15",
    "SET BLUE DUTY CYCLE TO 35",
    "SET BLUE DUTY CYCLE TO 100",
    "ENABLE_SOUND_CONTROL",
    "DISABLE_SOUND_CONTROL",
    "SPRAY FOR 5 SECONDS"
]

# 创建保存二维码的文件夹
output_dir = "C:/Users/18518/PycharmProjects/pythonProject1/qrcodes"
os.makedirs(output_dir, exist_ok=True)

# 生成二维码并保存到文件
for command in commands:
    img = qrcode.make(command)
    # 替换命令中的空格和特殊字符以适合作为文件名
    safe_filename = command.replace(" ", "_").replace(":", "").replace("/", "_")
    img.save(f"{output_dir}/{safe_filename}.png")
    print(f"Generated QR code for command: {command}")

print("All QR codes generated and saved.")
