import multiprocessing
import random
import time
import tkinter as tk
import pyautogui
import qrcode
from PIL import Image
from PIL import ImageTk
from pyzbar.pyzbar import decode
import serial


def generate():
    # 创建GUI窗口
    window = tk.Tk()
    window.title("QR Code Display")

    # 创建标签用于展示二维码图像
    qr_label = tk.Label(window)
    qr_label.pack()

    # 循环生成不同内容的二维码并展示
    qr_contents = ["C1", "C2", "C3"]  # 二维码内容列表
    for i in range(1000):
        # index = i % len(qr_contents)
        index = random.randint(0, len(qr_contents) - 1)
        content = qr_contents[index]
        # 创建二维码对象
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=10,
            border=4,
        )

        # 添加数据到二维码
        qr.add_data(content)
        qr.make(fit=True)

        # 创建图像
        img = qr.make_image(fill_color="black", back_color="white")

        # 将PIL图像转换为Tkinter可用的图像格式
        img_tk = ImageTk.PhotoImage(img)

        # 更新标签展示新的二维码图像
        qr_label.config(image=img_tk)
        qr_label.image = img_tk  # 保持对图像对象的引用，防止被垃圾回收

        # 刷新窗口
        window.update()

        # 等待一段时间
        time.sleep(5)  # 等待

    # 运行窗口主循环
    window.mainloop()


def scanner():
    # 定义特定窗口标题
    target_window_title = "QR Code Display"
    last_cmd = ""
    print("扫描器启动...")

    # 连接串口
    ser = serial.Serial('COM13', 9600, timeout=1)
    # 等待串口连接成功
    print("正在连接串口...")
    time.sleep(2.5)
    print("扫描器初始化完成...")

    while True:
        # start = time.time()
        # 获取目标窗口的位置和大小
        target_window = pyautogui.getWindowsWithTitle(target_window_title)[0]
        left = target_window.left
        top = target_window.top
        width = target_window.width
        height = target_window.height

        # 捕捉特定窗口的屏幕截图
        screenshot = pyautogui.screenshot(region=(left, top, width, height))

        # 将屏幕截图转换为PIL图像
        pil_image = Image.frombytes('RGB', screenshot.size, screenshot.tobytes())

        # 使用pyzbar进行二维码识别
        results = decode(pil_image)
        # 打印识别到的二维码内容
        if results:
            current_cmd = results[0].data.decode("utf-8")
            # print("QR Code Content:", current_cmd)
            # check if it should send cmd
            if current_cmd != last_cmd:
                last_cmd = current_cmd
                cmd_to_send = get_cmd(current_cmd)
                if cmd_to_send is not None and cmd_to_send != "":
                    # 发送指令
                    message = cmd_to_send + '\n'
                    ser.write(message.encode())
                    print(f"指令已发送: {cmd_to_send}")
                else:
                    print("指令发送失败: 识别到空指令")
        else:
            print("No QR Code found.")
        # end = time.time()
        # print(f"识别花费时间: {(end - start) * 1000}ms")
        time.sleep(0.1)


def get_cmd(cmd):
    cmd_list = ["TURN_ON_LIGHT", "TURN_OFF_LIGHT", "BLINK_LIGHT"]
    cmd_to_send = ""
    if cmd == "C1":
        cmd_to_send = cmd_list[0]
    elif cmd == "C2":
        cmd_to_send = cmd_list[1]
    elif cmd == "C3":
        cmd_to_send = cmd_list[2]
    else:
        print(f"注意！识别到错误指令：{cmd}")
    return cmd_to_send


# run
if __name__ == "__main__":
    process1 = multiprocessing.Process(target=generate)
    process2 = multiprocessing.Process(target=scanner)
    process1.start()
    time.sleep(3)
    process2.start()

    process1.join()
    process2.join()
