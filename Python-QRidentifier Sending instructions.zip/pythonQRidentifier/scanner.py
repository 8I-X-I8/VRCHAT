import time

import pyautogui
from pyzbar.pyzbar import decode
from PIL import Image

# 定义特定窗口标题
target_window_title = "QR Code Display"
while True:
    start = time.time()
    # 获取目标窗口的位置和大小
    target_window = pyautogui.getWindowsWithTitle(target_window_title)[0]
    left = target_window.left
    top = target_window.top
    width = target_window.width
    height = target_window.height
    # print(width)
    # print(height)

    # 捕捉特定窗口的屏幕截图
    screenshot = pyautogui.screenshot(region=(left, top, width, height))

    # 将屏幕截图转换为PIL图像
    pil_image = Image.frombytes('RGB', screenshot.size, screenshot.tobytes())

    # 使用pyzbar进行二维码识别
    results = decode(pil_image)
    # 打印识别到的二维码内容
    if results:
        for result in results:
            print("QR Code Content:", result.data.decode("utf-8"))
    else:
        print("No QR Code found.")
    end = time.time()
    print(f"识别花费时间: {(end - start) * 1000}ms")
    time.sleep(0.1)
